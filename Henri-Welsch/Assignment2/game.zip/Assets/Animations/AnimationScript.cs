using System.Collections;
using UnityEngine;

public class AnimationCycler : MonoBehaviour
{
    public Animator animator;

    [Header("Animation States")]
    public string[] animationStates = { "Idle", "Walk", "Run", "Crawl" };

    [Header("Settings")]
    public float timePerAnimation = 3f;
    public bool loop = true;

    private void Start()
    {
        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }
        StartCoroutine(CycleAnimations());
    }

    IEnumerator CycleAnimations()
    {
        do
        {
            foreach (string stateName in animationStates)
            {
                Debug.Log("[AnimationCycler] Playing animation: " + stateName);
                animator.Play(stateName);

                yield return new WaitForSeconds(timePerAnimation);
            }
        }
        while (loop);
    }
}
