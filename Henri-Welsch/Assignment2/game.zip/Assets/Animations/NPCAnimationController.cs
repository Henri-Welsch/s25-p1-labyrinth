using UnityEngine;

public class NPCAnimationController : MonoBehaviour
{
    public Animator animator;

    public void PlayAnimation(string stateName)
    {
        Debug.Log("[NPCAnimationController] Switching to animation: " + stateName);
        animator.Play(stateName);
    }
}
