using System.Collections;
using UnityEngine;

public class WaypointMover : MonoBehaviour
{
    public Transform waypointParent;
    public float defaultMoveSpeed = 2f; // renamed for clarity
    public float waitTime = 2f;
    public bool loopWaypoints = true;
    public float rotationSpeed = 5f;

    private Transform[] waypoints;
    private int currentWaypointIndex;
    private bool isWaiting;

    [Header("Movement Control")]
    public bool isMoving = false; // starts false so NPC idles
    private float currentMoveSpeed; // NEW: actual speed used while moving

    void Start()
    {
        if (waypointParent == null)
        {
            Debug.LogError("WaypointMover: waypointParent is not assigned!");
            enabled = false;
            return;
        }

        waypoints = new Transform[waypointParent.childCount];

        if (waypoints.Length == 0)
        {
            Debug.LogError("WaypointMover: waypointParent has no child waypoints!");
            enabled = false;
            return;
        }

        for (int i = 0; i < waypointParent.childCount; i++)
        {
            waypoints[i] = waypointParent.GetChild(i);
        }

        // Snap to first waypoint at start
        transform.position = new Vector3(
            waypoints[0].position.x,
            transform.position.y,
            waypoints[0].position.z
        );

        currentMoveSpeed = defaultMoveSpeed; // start with default speed
    }

    void Update()
    {
        if (isWaiting || !isMoving)
        {
            return;
        }

        MoveToWaypoint();
    }

    void MoveToWaypoint()
    {
        Transform target = waypoints[currentWaypointIndex];

        Vector3 targetPosition = new Vector3(
            target.position.x,
            transform.position.y,
            target.position.z
        );

        Vector3 direction = targetPosition - transform.position;
        direction.y = 0f;

        if (direction.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                targetRotation,
                rotationSpeed * Time.deltaTime
            );
        }

        transform.position = Vector3.MoveTowards(
            transform.position,
            targetPosition,
            currentMoveSpeed * Time.deltaTime
        );

        if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
        {
            StartCoroutine(WaitAtWaypoint());
        }
    }

    IEnumerator WaitAtWaypoint()
    {
        isWaiting = true;
        yield return new WaitForSeconds(waitTime);
        currentWaypointIndex = loopWaypoints
            ? (currentWaypointIndex + 1) % waypoints.Length
            : Mathf.Min(currentWaypointIndex + 1, waypoints.Length - 1);
        isWaiting = false;
    }

    // Start/Stop moving
    public void StartMoving()
    {
        Debug.Log("[WaypointMover] StartMoving called");
        isMoving = true;
    }

    public void StopMoving()
    {
        Debug.Log("[WaypointMover] StopMoving called");
        isMoving = false;
    }

    // NEW: Change speed dynamically
    public void SetMoveSpeed(float newSpeed)
    {
        Debug.Log("[WaypointMover] Speed set to: " + newSpeed);
        currentMoveSpeed = newSpeed;
    }
}
