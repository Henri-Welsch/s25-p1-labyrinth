using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;
using UnityEngine.Networking;
using System.Text;
using System.Collections;

[System.Serializable]
public class ChatCompletionChoice
{
    public ChatMessage message;
}

[System.Serializable]
public class ChatCompletionResponse
{
    public ChatCompletionChoice[] choices;
}

[System.Serializable]
public class ChatMessage
{
    public string role;
    public string content;
}

public class DialogManager : MonoBehaviour
{
    [Header("UI References")]
    public GameObject dialogPanel;
    public TMP_InputField messageInput;
    public Button sendButton;
    public Button closeButton;

    [Header("ChatGPT API")]
    [TextArea]
    public string apiKey = "sk-...";

    [Header("NPC Controller")]
    public NPCAnimationController npcAnimationController;

    [Header("NPC Movement")]
    public WaypointMover waypointMover; // NEW: reference to the mover script

    private bool isDialogOpen = false;

    void Start()
    {
        dialogPanel.SetActive(false);

        sendButton.onClick.AddListener(OnSend);
        closeButton.onClick.AddListener(CloseDialog);
    }

    void Update()
    {
        if (!isDialogOpen)
        {
            if (Keyboard.current.eKey.wasPressedThisFrame)
            {
                OpenDialog();
            }
        }
        else
        {
            if (Keyboard.current.enterKey.wasPressedThisFrame)
            {
                OnSend();
            }

            if (Keyboard.current.escapeKey.wasPressedThisFrame)
            {
                CloseDialog();
            }
        }
    }

    void OpenDialog()
    {
        dialogPanel.SetActive(true);
        Time.timeScale = 0f;
        isDialogOpen = true;
        StartCoroutine(FocusInputFieldNextFrame());
    }

    private IEnumerator FocusInputFieldNextFrame()
    {
        yield return null;
        messageInput.ActivateInputField();
    }

    void CloseDialog()
    {
        dialogPanel.SetActive(false);
        Time.timeScale = 1f;
        isDialogOpen = false;
        messageInput.text = "";
    }

    void OnSend()
    {
        string userMessage = messageInput.text;
        Debug.Log("[Dialog] Player Message: " + userMessage);

        StartCoroutine(SendGPTRequest(userMessage));

        CloseDialog();
    }

    IEnumerator SendGPTRequest(string prompt)
    {
        Debug.Log("[ChatGPT] Sending request...");

        string url = "https://api.openai.com/v1/chat/completions";

        string jsonBody = $@"
        {{
            ""model"": ""gpt-3.5-turbo"",
            ""messages"": [
                {{""role"": ""system"", ""content"": ""You are an NPC in a game. When the user gives you instructions, you must respond in the format: ACTION: [IDLE/WALK/RUN/CRAWL] and nothing else."" }},
                {{""role"": ""user"", ""content"": ""{EscapeJson(prompt)}"" }}
            ]
        }}";

        byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonBody);

        UnityWebRequest request = new UnityWebRequest(url, "POST");
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        request.SetRequestHeader("Authorization", "Bearer " + apiKey);

        yield return request.SendWebRequest();

        string responseText = request.downloadHandler.text;

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("[ChatGPT] Raw Response:\n" + responseText);

            ChatCompletionResponse response = JsonUtility.FromJson<ChatCompletionResponse>(responseText);
            if (response != null && response.choices != null && response.choices.Length > 0)
            {
                string reply = response.choices[0].message.content.Trim();
                Debug.Log("[ChatGPT] Assistant Reply:\n" + reply);

                // Parse the action
                if (reply.StartsWith("ACTION:"))
                {
                    string action = reply.Substring("ACTION:".Length).Trim().ToUpper();

                    switch (action)
                    {
                        case "IDLE":
                            npcAnimationController.PlayAnimation("Idle");
                            waypointMover.StopMoving();
                            break;
                        case "WALK":
                            npcAnimationController.PlayAnimation("Walking");
        		    waypointMover.SetMoveSpeed(3f); // slower walk speed
                            waypointMover.StartMoving();
                            break;
                        case "RUN":
                            npcAnimationController.PlayAnimation("Slow Run");
        		    waypointMover.SetMoveSpeed(5f); // faster run speed
                            waypointMover.StartMoving();
                            break;
                        case "CRAWL":
                            npcAnimationController.PlayAnimation("Low Crawl");
        		    waypointMover.SetMoveSpeed(1f); // slower walk speed
                            waypointMover.StartMoving();
                            break;
                        default:
                            Debug.LogWarning("[ChatGPT] Unknown action: " + action);
                            break;
                    }
                }
                else
                {
                    Debug.LogWarning("[ChatGPT] Reply does not contain ACTION directive.");
                }
            }
            else
            {
                Debug.LogWarning("[ChatGPT] Could not parse the response JSON.");
            }
        }
        else
        {
            Debug.LogError("[ChatGPT] Request failed: " + request.error);
            Debug.LogError("[ChatGPT] Response body:\n" + responseText);
        }
    }

    private string EscapeJson(string text)
    {
        return text.Replace("\\", "\\\\").Replace("\"", "\\\"");
    }
}
